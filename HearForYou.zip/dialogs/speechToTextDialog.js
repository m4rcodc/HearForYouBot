const fs = require('fs');
const path = require('path');
const sdk = require("microsoft-cognitiveservices-speech-sdk");
//const speechConfig = sdk.SpeechConfig.fromSubscription("68befe3c7508400196b3472c4a12ac66", "westeurope");
const sleep = require('util').promisify(setTimeout);
var subscriptionKey = "68befe3c7508400196b3472c4a12ac66";
var serviceRegion = "westeurope";



const {
    ActionTypes,
    ActivityTypes,
    CardFactory,
    ActivityHandler
} = require('botbuilder');

const {
    TextPrompt,
    ComponentDialog,
    DialogSet,
    DialogTurnStatus,
    WaterfallDialog,
    ThisMemoryScope,
    AttachmentPrompt
} = require('botbuilder-dialogs');

const axios = require('axios').default;
const { SimpleSpeechPhrase } = require('microsoft-cognitiveservices-speech-sdk/distrib/lib/src/common.speech/Exports');
const { writeHeapSnapshot } = require('v8');
const Bluebird = require('bluebird');

const WATERFALL_DIALOG = 'WATERFALL_DIALOG';
const ATT_PROMPT = 'ATT_PROMPT';
const SPEECHTOTEXT_DIALOG = 'SPEECHTOTEXT_DIALOG'
var value = null;
var textStampato = null;


class SpeechToTextDialog extends ComponentDialog {
    constructor(userState) {
        super(SPEECHTOTEXT_DIALOG);

        this.userState = userState;
        this.addDialog(new AttachmentPrompt('ATT_PROMPT'));
        this.addDialog(new WaterfallDialog(WATERFALL_DIALOG, [
            this.introStep.bind(this),
            this.speechToText.bind(this),
            this.finalStep.bind(this)
        ]));

        this.initialDialogId = WATERFALL_DIALOG;
    }

    async run(turnContext, accessor) {
        const dialogSet = new DialogSet(accessor);
        dialogSet.add(this);

        const dialogContext = await dialogSet.createContext(turnContext);
        const results = await dialogContext.continueDialog();
        if (results.status === DialogTurnStatus.empty) {
            await dialogContext.beginDialog(this.id);
        }
    }

    async introStep(step) {

        return await step.prompt(ATT_PROMPT, {
            prompt: 'Dammi un file audio in input'
        });
    }  

    async speechToText(step) {
        
        const result = step.result;
        //console.log(result[0]);
        const attach = Object.values(result);
        for (const key in attach) {
            if (attach.hasOwnProperty(key)) {
                value = attach[key];        
            }
        }

        const msg = await recognizeAudio(value);
        console.log(msg);
        await sleep(10000);
        await step.context.sendActivity(msg);
        
}

            async finalStep(step) {

            return await step.endDialog();
        }

}


async function recognizeAudio(value) {

    const audioFile = await downloadAttachmentAndWrite(value);
    console.log(audioFile.fileName);
    console.log(audioFile.localPath);
    

    const dir = audioFile.localPath;

    const name= value.name;

    let result;
    await sleep(10000);
    result = await fromFile(dir);
    //console.log(result);
    await sleep(10000);
    result = await result();
    await sleep(10000);
    console.log(result);
    return result.text;
    

 async function fromFile(dir) {


    let pushStream = sdk.AudioInputStream.createPushStream();

    fs.createReadStream(dir)
    .on('data',function(arrayBuffer) {
        pushStream.write(arrayBuffer.slice());
    })
    .on('end',function() {
        pushStream.close();
    });


    //const localAudioPath = __dirname + '\\' + value.name ;
    let audioConfig = sdk.AudioConfig.fromStreamInput(pushStream);
    const speechConfig = sdk.SpeechConfig.fromSubscription(subscriptionKey,serviceRegion);
    let recognizer = new sdk.SpeechRecognizer(speechConfig, audioConfig);
    speechConfig.speechRecognitionLanguage = "it-IT";

    console.log("sono qui");
    const recognize = () => {
        return new Promise((resolve,reject) => {
            recognizer.recognizeOnceAsync(
                (result) => {

                    if(result) resolve(result);
                },
                (err) => {
                    if (err){

                     reject(err);
                }
                recognizer.close();
                },
            );

        });
    };

    return recognize;

 }
}


        /*
        recognizeOnceAsync(result => {
        switch (result.reason) {
            case sdk.ResultReason.RecognizedSpeech:
                console.log(`RECOGNIZED: Text=${result.text}`);
                textStampato = result.text;
                recognizer.close();
                break;
            case sdk.ResultReason.NoMatch:
                console.log("NOMATCH: Speech could not be recognized.");
                break;
            case sdk.ResultReason.Canceled:
                const cancellation = CancellationDetails.fromResult(result);
                console.log(`CANCELED: Reason=${cancellation.reason}`);

                if (cancellation.reason == sdk.CancellationReason.Error) {
                    console.log(`CANCELED: ErrorCode=${cancellation.ErrorCode}`);
                    console.log(`CANCELED: ErrorDetails=${cancellation.errorDetails}`);
                    console.log("CANCELED: Did you update the key and location/region info?");
                }
                break;
        }
        recognizer.close();
    });
}
*/
 async function downloadAttachmentAndWrite(attachment) {
    // Retrieve the attachment via the attachment's contentUrl.
    const url = attachment.contentUrl;

    // Local file path for the bot to save the attachment.
    const localFileName = path.join(__dirname.replace('dialogs','bots'),'/audio', attachment.name);

    try {
        // arraybuffer is necessary for images
        const response = await axios.get(url, { responseType: 'arraybuffer' });
        // If user uploads JSON file, this prevents it from being written as "{"type":"Buffer","data":[123,13,10,32,32,34,108..."
        if (response.headers['content-type'] === 'application/json') {
            response.data = JSON.parse(response.data, (key, value) => {
                return value && value.type === 'Buffer' ? Buffer.from(value.data) : value;
            });
        }
      fs.writeFile(localFileName, response.data, (fsError) => {
            if (fsError) {
                throw fsError;
            }
        });
    } catch (error) {
        console.error(error);
        return undefined;
    }
    // If no error was thrown while writing to disk, return the attachment's name
    // and localFilePath for the response back to the user.
    return {
        fileName: attachment.name,
        localPath: localFileName
    };
 }  

module.exports.SpeechToTextDialog = SpeechToTextDialog;
module.exports.SPEECHTOTEXT_DIALOG = this.SPEECHTOTEXT_DIALOG;